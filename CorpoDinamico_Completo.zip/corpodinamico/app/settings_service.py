"""
settings_service.py
--------------------
Configurações do sistema (seções 30 e 76): nada de regra fixa no código.
Tudo fica na tabela `settings`, com valores padrão sensatos na primeira
execução, editáveis pelo administrador depois.
"""

from datetime import datetime, timezone
from app.db import transaction, get_connection

DEFAULTS = {
    "academia_nome": "Corpo Dinâmico Academia",
    "tolerancia_dias": "5",        # dias de tolerância após o vencimento antes de virar "atraso"
    "atraso_dias": "10",           # dias em atraso antes de virar "inadimplente"
    "inadimplencia_dias": "20",    # dias inadimplente antes de virar "inativo por inadimplência"
    "inatividade_dias": "45",      # dias sem pagamento (após inadimplência) até inativação automática
    "min_espaco_livre_mb": "200",  # espaço livre mínimo em disco antes de alertar/bloquear
}


def _now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S")


def seed_defaults() -> None:
    """Insere os valores padrão apenas se ainda não existirem (não sobrescreve
    configurações já feitas pelo administrador)."""
    now = _now_iso()
    with transaction() as conn:
        for key, value in DEFAULTS.items():
            exists = conn.execute("SELECT 1 FROM settings WHERE key=?;", (key,)).fetchone()
            if not exists:
                conn.execute(
                    "INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?);",
                    (key, value, now),
                )


def get(key: str) -> str:
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key=?;", (key,)).fetchone()
    conn.close()
    if row is None:
        if key in DEFAULTS:
            return DEFAULTS[key]
        raise KeyError(f"Configuração '{key}' não existe.")
    return row["value"]


def get_int(key: str) -> int:
    return int(get(key))


def get_all() -> dict:
    conn = get_connection()
    rows = conn.execute("SELECT key, value FROM settings;").fetchall()
    conn.close()
    result = dict(DEFAULTS)
    result.update({r["key"]: r["value"] for r in rows})
    return result


def set_value(key: str, value: str, user_id: int) -> None:
    now = _now_iso()
    with transaction() as conn:
        old = conn.execute("SELECT value FROM settings WHERE key=?;", (key,)).fetchone()
        conn.execute(
            """INSERT INTO settings (key, value, updated_at, updated_by) VALUES (?, ?, ?, ?)
               ON CONFLICT(key) DO UPDATE SET value=excluded.value,
                   updated_at=excluded.updated_at, updated_by=excluded.updated_by;""",
            (key, value, now, user_id),
        )
        conn.execute(
            """INSERT INTO audit_log (user_id, action, entity, entity_id, old_value, new_value, created_at)
               VALUES (?, 'alterar_configuracao', 'settings', NULL, ?, ?, ?)""",
            (user_id, old["value"] if old else None, value, now),
        )
