"""
system_health.py
------------------
"Saúde do sistema" (seções 49-51, 81). Responde perguntas objetivas:
banco íntegro? espaço livre? último backup? versão? modo somente leitura?
"""

import os
import shutil
from datetime import datetime

from app.paths import DATA_ROOT, DATABASE_PATH
from app.db import get_connection, check_integrity
from app import settings_service
from app.backup_service import list_backups, APP_VERSION, DB_VERSION
from app.logger import log_warning


def _now():
    return datetime.now()


def get_health() -> dict:
    integrity_ok, integrity_detail = check_integrity()

    db_size_mb = round(os.path.getsize(DATABASE_PATH) / (1024 * 1024), 2) if os.path.exists(DATABASE_PATH) else 0

    total, used, free = shutil.disk_usage(DATA_ROOT)
    free_mb = round(free / (1024 * 1024), 1)
    min_free_mb = settings_service.get_int("min_espaco_livre_mb")
    espaco_critico = free_mb < min_free_mb

    backups = list_backups()
    ultimo_backup = backups[0] if backups else None
    backup_antigo = True
    dias_desde_backup = None
    if ultimo_backup:
        dt = datetime.strptime(ultimo_backup["created_at"], "%Y-%m-%d %H:%M:%S")
        dias_desde_backup = (_now() - dt).days
        backup_antigo = dias_desde_backup > 7

    conn = get_connection()
    total_alunos = conn.execute("SELECT COUNT(*) c FROM students;").fetchone()["c"]
    total_pagamentos = conn.execute("SELECT COUNT(*) c FROM payments WHERE reversed=0;").fetchone()["c"]
    conn.close()

    read_only_mode = (not integrity_ok) or espaco_critico

    alertas = []
    if not integrity_ok:
        alertas.append("O banco de dados não passou na verificação de integridade.")
    if espaco_critico:
        alertas.append(f"Espaço livre em disco baixo: {free_mb} MB (mínimo configurado: {min_free_mb} MB).")
    if backup_antigo:
        if ultimo_backup:
            alertas.append(f"O último backup foi feito há {dias_desde_backup} dia(s). Considere fazer um novo.")
        else:
            alertas.append("Nenhum backup foi feito ainda.")

    return {
        "versao_app": APP_VERSION,
        "versao_banco": DB_VERSION,
        "banco_integro": integrity_ok,
        "banco_detalhe": integrity_detail,
        "tamanho_banco_mb": db_size_mb,
        "espaco_livre_mb": free_mb,
        "espaco_critico": espaco_critico,
        "total_alunos": total_alunos,
        "total_pagamentos": total_pagamentos,
        "ultimo_backup": ultimo_backup,
        "dias_desde_ultimo_backup": dias_desde_backup,
        "backup_desatualizado": backup_antigo,
        "modo_somente_leitura": read_only_mode,
        "local_execucao": DATA_ROOT,
        "alertas": alertas,
    }


def guard_write_allowed() -> None:
    """Chamar antes de qualquer operação de escrita crítica. Bloqueia
    gravações se houver risco grave de corrupção (seção 51)."""
    health = get_health()
    if health["modo_somente_leitura"]:
        log_warning("Gravação bloqueada: sistema em modo somente leitura.")
        raise SystemInReadOnlyMode(
            "O sistema detectou um problema que pode comprometer a integridade dos dados. "
            "As gravações foram temporariamente bloqueadas. Consulte Saúde do Sistema."
        )


class SystemInReadOnlyMode(Exception):
    pass
