"""
dashboard_service.py
---------------------
Agrega dados REAIS para o painel (seções 37-39). Nunca inventa números.
Usa finance_service como única fonte da verdade financeira (seção 40).
"""

from datetime import date, datetime
from app.db import get_connection
from app import finance_service
from app.money import cents_to_brl


def _month_bounds(ym: str) -> tuple[str, str]:
    return f"{ym}-01", f"{ym}-31"


def overview(as_of: date | None = None) -> dict:
    as_of = as_of or date.today()
    conn = get_connection()

    total_ativos = conn.execute("SELECT COUNT(*) c FROM students WHERE status='ativo';").fetchone()["c"]
    total_inativos = conn.execute("SELECT COUNT(*) c FROM students WHERE status IN ('inativo','encerrado');").fetchone()["c"]

    students = conn.execute("SELECT id FROM students WHERE status='ativo';").fetchall()
    conn.close()

    em_dia = atraso = inadimplentes = 0
    for s in students:
        st = finance_service.compute_financial_status(s["id"], as_of=as_of)["status"]
        if st == "em_dia":
            em_dia += 1
        elif st == "atraso":
            atraso += 1
        elif st in ("inadimplente", "inativo_por_inadimplencia"):
            inadimplentes += 1

    # eventos do mês corrente
    ym = as_of.strftime("%Y-%m")
    conn = get_connection()
    novos = conn.execute(
        "SELECT COUNT(*) c FROM student_events WHERE event_type='cadastro' AND event_date LIKE ?;",
        (f"{ym}%",),
    ).fetchone()["c"]
    reativacoes = conn.execute(
        "SELECT COUNT(*) c FROM student_events WHERE event_type='reativacao' AND event_date LIKE ?;",
        (f"{ym}%",),
    ).fetchone()["c"]
    encerramentos = conn.execute(
        "SELECT COUNT(*) c FROM student_events WHERE event_type='encerramento' AND event_date LIKE ?;",
        (f"{ym}%",),
    ).fetchone()["c"]

    receita_mes = conn.execute(
        """SELECT COALESCE(SUM(p.amount_cents), 0) t FROM payments p
           WHERE p.reversed=0 AND p.payment_date LIKE ?;""",
        (f"{ym}%",),
    ).fetchone()["t"]

    pendente_cents = 0
    for s in students:
        plan = finance_service.get_current_plan(s["id"], conn=conn)
        if plan:
            status = finance_service.compute_financial_status(s["id"], as_of=as_of)
            if status["status"] in ("atraso", "inadimplente", "inativo_por_inadimplencia"):
                pendente_cents += plan["value_cents"]

    proximos_vencimentos = []
    for s in students:
        plan = finance_service.get_current_plan(s["id"], conn=conn)
        if not plan:
            continue
        next_due = finance_service.get_next_due_competency(s["id"])
        if next_due:
            y, m = map(int, next_due.split("-"))
            due_date = date(y, m, min(plan["due_day"], 28))
            days_ahead = (due_date - as_of).days
            if 0 <= days_ahead <= 7:
                name_row = conn.execute("SELECT full_name FROM students WHERE id=?;", (s["id"],)).fetchone()
                proximos_vencimentos.append({
                    "student_id": s["id"], "nome": name_row["full_name"],
                    "vencimento": due_date.isoformat(), "valor": cents_to_brl(plan["value_cents"]),
                })

    pagamentos_recentes = conn.execute(
        """SELECT p.id, p.amount_cents, p.payment_date, s.full_name FROM payments p
           JOIN students s ON s.id = p.student_id
           WHERE p.reversed=0
           ORDER BY p.created_at DESC LIMIT 8;"""
    ).fetchall()
    conn.close()

    return {
        "alunos_ativos": total_ativos,
        "alunos_inativos": total_inativos,
        "em_dia": em_dia,
        "em_atraso": atraso,
        "inadimplentes": inadimplentes,
        "novos_no_mes": novos,
        "reativacoes_no_mes": reativacoes,
        "encerramentos_no_mes": encerramentos,
        "receita_mes_cents": receita_mes,
        "receita_mes_fmt": cents_to_brl(receita_mes),
        "pendente_cents": pendente_cents,
        "pendente_fmt": cents_to_brl(pendente_cents),
        "proximos_vencimentos": sorted(proximos_vencimentos, key=lambda x: x["vencimento"]),
        "pagamentos_recentes": [
            {"id": r["id"], "aluno": r["full_name"], "valor": cents_to_brl(r["amount_cents"]),
             "data": r["payment_date"]}
            for r in pagamentos_recentes
        ],
    }


def revenue_evolution(months_back: int = 6, as_of: date | None = None) -> dict:
    """Série mensal de receita para gráfico. Se não houver dados
    suficientes (menos de 2 meses com movimento), avisa em vez de inventar."""
    as_of = as_of or date.today()
    conn = get_connection()
    series = []
    y, m = as_of.year, as_of.month
    months = []
    for i in range(months_back - 1, -1, -1):
        yy, mm = finance_service._add_months(y, m, -i)
        months.append(f"{yy:04d}-{mm:02d}")

    for ym in months:
        total = conn.execute(
            "SELECT COALESCE(SUM(amount_cents),0) t FROM payments WHERE reversed=0 AND payment_date LIKE ?;",
            (f"{ym}%",),
        ).fetchone()["t"]
        series.append({"mes": ym, "receita_cents": total})
    conn.close()

    meses_com_dado = sum(1 for s in series if s["receita_cents"] > 0)
    if meses_com_dado < 2:
        return {"suficiente": False, "mensagem": "Sem dados suficientes para comparação.", "serie": series}
    return {"suficiente": True, "serie": series}
