"""
migrations_runner.py
---------------------
Aplica migrations SQL numeradas (001_initial.sql, 002_xxx.sql, ...) de
forma controlada e idempotente (seção 60).

Fluxo obrigatório antes de qualquer migration:
    Validar -> Backup -> Migration -> Validar -> Testar
Aqui implementamos a parte "Validar -> Migration -> Validar".
O backup automático pré-migration é feito por backup_service.py e
chamado a partir de main.py antes de invocar este runner.
"""

import os
import glob
from datetime import datetime, timezone

from app.db import get_connection, check_integrity
from app.logger import log_info, log_error

MIGRATIONS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "migrations")


def _now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S")


def _get_applied_versions(conn) -> set:
    cur = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='schema_migrations';"
    )
    if cur.fetchone() is None:
        return set()
    rows = conn.execute("SELECT version FROM schema_migrations;").fetchall()
    return {r[0] for r in rows}


def run_migrations() -> None:
    """Aplica, em ordem, todas as migrations ainda não aplicadas.
    Cada migration roda em sua própria transação: se uma falhar, as
    anteriores já aplicadas permanecem válidas, e a falha é registrada
    e propagada (o sistema não deve seguir em frente com banco inconsistente).
    """
    files = sorted(glob.glob(os.path.join(MIGRATIONS_DIR, "*.sql")))
    if not files:
        log_info("Nenhum arquivo de migration encontrado.")
        return

    conn = get_connection()
    applied = _get_applied_versions(conn)

    for path in files:
        filename = os.path.basename(path)
        version = int(filename.split("_")[0])
        if version in applied:
            continue

        log_info(f"Aplicando migration {filename} ...")
        with open(path, "r", encoding="utf-8") as f:
            sql = f.read()

        try:
            conn.executescript(sql)
            conn.execute(
                "CREATE TABLE IF NOT EXISTS schema_migrations "
                "(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);"
            )
            conn.execute(
                "INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?);",
                (version, _now_iso()),
            )
            conn.commit()
            log_info(f"Migration {filename} aplicada com sucesso.")
        except Exception as exc:
            conn.rollback()
            log_error(f"Falha ao aplicar migration {filename}. Banco NÃO foi alterado por ela.", exc)
            conn.close()
            raise RuntimeError(
                f"Não foi possível aplicar a migration {filename}. "
                f"O sistema foi interrompido para proteger a integridade dos dados."
            ) from exc

    conn.close()

    ok, detail = check_integrity()
    if not ok:
        log_error(f"Verificação de integridade falhou após migrations: {detail}")
        raise RuntimeError(
            "O banco de dados não passou na verificação de integridade após a "
            "atualização de estrutura. O sistema foi interrompido por segurança."
        )
    log_info("Todas as migrations aplicadas e integridade confirmada.")
