"""
logger.py
---------
Log técnico do sistema (seção 59 do escopo).

Regra: nunca registrar senhas ou dados sensíveis aqui. Isso é só para
diagnosticar problemas técnicos (erros, inicialização, backup, banco).
"""

import logging
import logging.handlers
from app.paths import LOG_PATH, ensure_all_dirs

_logger = None


def get_logger() -> logging.Logger:
    global _logger
    if _logger is not None:
        return _logger

    ensure_all_dirs()

    logger = logging.getLogger("corpodinamico")
    logger.setLevel(logging.INFO)

    # Rotaciona o log em 2 MB, mantém 5 arquivos antigos — nunca cresce sem limite
    handler = logging.handlers.RotatingFileHandler(
        LOG_PATH, maxBytes=2 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    _logger = logger
    return logger


def log_info(msg: str) -> None:
    get_logger().info(msg)


def log_error(msg: str, exc: Exception = None) -> None:
    if exc is not None:
        get_logger().error(f"{msg} | Exceção técnica: {exc!r}")
    else:
        get_logger().error(msg)


def log_warning(msg: str) -> None:
    get_logger().warning(msg)
