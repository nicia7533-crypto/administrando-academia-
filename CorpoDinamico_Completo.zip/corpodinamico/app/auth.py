"""
auth.py
-------
Autenticação real (seção 31).

- Senha NUNCA é armazenada em texto puro.
- Hash: PBKDF2-HMAC-SHA256 com salt único por usuário e 200.000 iterações
  (biblioteca padrão do Python — hashlib — sem dependência externa frágil
  para uma operação tão crítica quanto essa).
- Sem senha mestra escondida, sem backdoor, sem credencial fixa no código.
- Bloqueio após tentativas excessivas (proteção contra força bruta).
"""

import hashlib
import hmac
import os
import secrets
from datetime import datetime, timedelta, timezone

from app.db import transaction, get_connection
from app.logger import log_info, log_warning, log_error

PBKDF2_ITERATIONS = 200_000
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_MINUTES = 15


class AuthError(Exception):
    """Erro de autenticação genérico e seguro (nunca revela detalhes técnicos)."""


class InvalidCredentials(AuthError):
    pass


class AccountLocked(AuthError):
    def __init__(self, minutes_remaining: int):
        self.minutes_remaining = minutes_remaining
        super().__init__(f"Conta bloqueada por {minutes_remaining} minuto(s).")


class AccountInactive(AuthError):
    pass


def _now() -> datetime:
    return datetime.now(timezone.utc).astimezone()


def _now_iso() -> str:
    return _now().strftime("%Y-%m-%d %H:%M:%S")


def hash_password(password: str, salt_hex: str | None = None) -> tuple[str, str]:
    """Gera (hash_hex, salt_hex). Se salt não for passado, gera um novo aleatório."""
    if salt_hex is None:
        salt_hex = secrets.token_hex(16)
    salt_bytes = bytes.fromhex(salt_hex)
    derived = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt_bytes, PBKDF2_ITERATIONS
    )
    return derived.hex(), salt_hex


def verify_password(password: str, hash_hex: str, salt_hex: str) -> bool:
    candidate_hash, _ = hash_password(password, salt_hex)
    # comparação em tempo constante — evita timing attack
    return hmac.compare_digest(candidate_hash, hash_hex)


def has_any_user() -> bool:
    """Usado para saber se é a primeira execução (mostrar assistente de
    configuração inicial em vez de tela de login)."""
    conn = get_connection()
    row = conn.execute("SELECT COUNT(*) AS c FROM users;").fetchone()
    conn.close()
    return row["c"] > 0


def create_user(username: str, password: str, role: str, full_name: str,
                 created_by_id: int | None = None) -> int:
    if role not in ("admin", "professor"):
        raise ValueError("Papel inválido.")
    if len(password) < 6:
        raise ValueError("A senha precisa ter pelo menos 6 caracteres.")

    hash_hex, salt_hex = hash_password(password)
    now = _now_iso()
    with transaction() as conn:
        cur = conn.execute(
            """INSERT INTO users
               (username, password_hash, password_salt, role, full_name,
                active, failed_attempts, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, 1, 0, ?, ?)""",
            (username, hash_hex, salt_hex, role, full_name, now, now),
        )
        user_id = cur.lastrowid
        conn.execute(
            """INSERT INTO audit_log (user_id, action, entity, entity_id, new_value, created_at)
               VALUES (?, 'criar_usuario', 'users', ?, ?, ?)""",
            (created_by_id, user_id, f"username={username}, role={role}", now),
        )
    log_info(f"Usuário criado: {username} (papel={role})")
    return user_id


def authenticate(username: str, password: str) -> dict:
    """
    Retorna um dict com os dados públicos do usuário autenticado, ou
    levanta AuthError (InvalidCredentials / AccountLocked / AccountInactive).
    Nunca revela se foi o usuário ou a senha que estava errada — mensagem
    genérica para quem tenta adivinhar usuários válidos.
    """
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM users WHERE username = ?;", (username,)
    ).fetchone()

    if row is None:
        conn.close()
        log_warning(f"Tentativa de login com usuário inexistente: {username!r}")
        raise InvalidCredentials("Usuário ou senha inválidos.")

    if not row["active"]:
        conn.close()
        raise AccountInactive("Este usuário está desativado.")

    if row["locked_until"]:
        locked_until = datetime.strptime(row["locked_until"], "%Y-%m-%d %H:%M:%S")
        locked_until = locked_until.replace(tzinfo=_now().tzinfo)
        if _now() < locked_until:
            remaining = int((locked_until - _now()).total_seconds() // 60) + 1
            conn.close()
            raise AccountLocked(remaining)

    valid = verify_password(password, row["password_hash"], row["password_salt"])

    if not valid:
        failed = row["failed_attempts"] + 1
        locked_until_value = None
        if failed >= MAX_FAILED_ATTEMPTS:
            locked_until_value = (_now() + timedelta(minutes=LOCKOUT_MINUTES)).strftime("%Y-%m-%d %H:%M:%S")
            log_warning(f"Usuário {username!r} bloqueado por {LOCKOUT_MINUTES} min após {failed} tentativas.")
        conn.execute(
            "UPDATE users SET failed_attempts = ?, locked_until = ?, updated_at = ? WHERE id = ?;",
            (failed, locked_until_value, _now_iso(), row["id"]),
        )
        conn.commit()
        conn.close()
        if locked_until_value:
            raise AccountLocked(LOCKOUT_MINUTES)
        raise InvalidCredentials("Usuário ou senha inválidos.")

    # sucesso: zera tentativas
    conn.execute(
        "UPDATE users SET failed_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?;",
        (_now_iso(), row["id"]),
    )
    conn.commit()
    conn.close()
    log_info(f"Login bem-sucedido: {username}")

    return {
        "id": row["id"],
        "username": row["username"],
        "role": row["role"],
        "full_name": row["full_name"],
    }


def change_password(user_id: int, new_password: str, changed_by_id: int) -> None:
    if len(new_password) < 6:
        raise ValueError("A senha precisa ter pelo menos 6 caracteres.")
    hash_hex, salt_hex = hash_password(new_password)
    now = _now_iso()
    with transaction() as conn:
        conn.execute(
            "UPDATE users SET password_hash=?, password_salt=?, updated_at=? WHERE id=?;",
            (hash_hex, salt_hex, now, user_id),
        )
        conn.execute(
            """INSERT INTO audit_log (user_id, action, entity, entity_id, created_at)
               VALUES (?, 'alterar_senha', 'users', ?, ?)""",
            (changed_by_id, user_id, now),
        )
    log_info(f"Senha alterada para usuário id={user_id} por usuário id={changed_by_id}")
