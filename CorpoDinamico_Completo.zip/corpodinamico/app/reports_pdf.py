"""
reports_pdf.py
---------------
Geração de PDF profissional (seções 47-48).

Usa a MESMA camada de dados do dashboard (dashboard_service / finance_service)
— nunca recalcula números por conta própria, garantindo que o PDF sempre
bata com o que o sistema mostra em tela (seção 48, 90).
"""

import os
from datetime import datetime, date

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image, PageBreak
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT

from app.paths import REPORTS_DIR, LOGO_DIR, ensure_all_dirs
from app import dashboard_service, students_service, finance_service, settings_service
from app.money import cents_to_brl
from app.logger import log_info

ACCENT = colors.HexColor("#2E5138")
ACCENT_LIGHT = colors.HexColor("#DCE6DE")
ALERT = colors.HexColor("#8F3423")
INK = colors.HexColor("#1F2A24")
INK_SOFT = colors.HexColor("#5B6B60")

LOGO_PATH = os.path.join(LOGO_DIR, "logo-principal.png")


def _styles():
    ss = getSampleStyleSheet()
    ss.add(ParagraphStyle("TituloCapa", parent=ss["Title"], fontSize=22, textColor=INK,
                           alignment=TA_CENTER, spaceAfter=6))
    ss.add(ParagraphStyle("SubCapa", parent=ss["Normal"], fontSize=12, textColor=INK_SOFT,
                           alignment=TA_CENTER, spaceAfter=4))
    ss.add(ParagraphStyle("SecaoTitulo", parent=ss["Heading2"], fontSize=14, textColor=ACCENT,
                           spaceBefore=14, spaceAfter=8))
    ss.add(ParagraphStyle("Corpo", parent=ss["Normal"], fontSize=10, textColor=INK, leading=14))
    ss.add(ParagraphStyle("Rodape", parent=ss["Normal"], fontSize=8, textColor=INK_SOFT))
    return ss


def _header_footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(INK_SOFT)
    canvas.drawString(2 * cm, 1.2 * cm,
                       f"Corpo Dinâmico Academia — Relatório gerado em "
                       f"{datetime.now().strftime('%d/%m/%Y às %H:%M')}")
    canvas.drawRightString(A4[0] - 2 * cm, 1.2 * cm, f"Página {doc.page}")
    canvas.restoreState()


def generate_period_report(start_ym: str, end_ym: str, generated_by: str,
                            include_student_list: bool = True) -> str:
    """
    Gera o PDF do período [start_ym, end_ym] (formato 'YYYY-MM') e retorna
    o caminho do arquivo salvo em reports/.
    """
    ensure_all_dirs()
    ss = _styles()
    stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"Relatorio_CorpoDinamico_{start_ym}_a_{end_ym}_{stamp}.pdf"
    filepath = os.path.join(REPORTS_DIR, filename)

    doc = SimpleDocTemplate(
        filepath, pagesize=A4,
        topMargin=2 * cm, bottomMargin=2 * cm, leftMargin=2 * cm, rightMargin=2 * cm,
        title="Relatório Corpo Dinâmico Academia",
    )
    story = []

    # ---------- CAPA ----------
    if os.path.exists(LOGO_PATH):
        img = Image(LOGO_PATH, width=9 * cm, height=6 * cm)
        img.hAlign = "CENTER"
        story.append(Spacer(1, 1.5 * cm))
        story.append(img)
    story.append(Spacer(1, 1 * cm))
    story.append(Paragraph("Relatório Gerencial", ss["TituloCapa"]))
    story.append(Paragraph(f"Período: {start_ym} a {end_ym}", ss["SubCapa"]))
    story.append(Paragraph(f"Gerado por: {generated_by} em {datetime.now().strftime('%d/%m/%Y %H:%M')}",
                            ss["SubCapa"]))
    story.append(PageBreak())

    # ---------- RESUMO EXECUTIVO ----------
    overview = dashboard_service.overview()
    story.append(Paragraph("Resumo executivo", ss["SecaoTitulo"]))
    resumo_data = [
        ["Indicador", "Valor"],
        ["Alunos ativos", str(overview["alunos_ativos"])],
        ["Alunos inativos/encerrados", str(overview["alunos_inativos"])],
        ["Em dia", str(overview["em_dia"])],
        ["Em atraso", str(overview["em_atraso"])],
        ["Inadimplentes", str(overview["inadimplentes"])],
        ["Novos no mês corrente", str(overview["novos_no_mes"])],
        ["Reativações no mês corrente", str(overview["reativacoes_no_mes"])],
        ["Encerramentos no mês corrente", str(overview["encerramentos_no_mes"])],
        ["Receita do mês corrente", overview["receita_mes_fmt"]],
        ["Valores em aberto (estimado)", overview["pendente_fmt"]],
    ]
    t = Table(resumo_data, colWidths=[9 * cm, 6 * cm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), ACCENT),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9.5),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, ACCENT_LIGHT]),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#D8DCD2")),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(t)

    # ---------- FINANCEIRO DO PERÍODO ----------
    story.append(Paragraph("Financeiro do período", ss["SecaoTitulo"]))
    from app.db import get_connection
    conn = get_connection()
    recebido = conn.execute(
        "SELECT COALESCE(SUM(amount_cents),0) t FROM payments WHERE reversed=0 AND payment_date >= ? AND payment_date <= ?;",
        (f"{start_ym}-01", f"{end_ym}-31"),
    ).fetchone()["t"]
    estornado = conn.execute(
        "SELECT COALESCE(SUM(amount_cents),0) t FROM payments WHERE reversed=1 AND payment_date >= ? AND payment_date <= ?;",
        (f"{start_ym}-01", f"{end_ym}-31"),
    ).fetchone()["t"]
    qtd_pagamentos = conn.execute(
        "SELECT COUNT(*) c FROM payments WHERE reversed=0 AND payment_date >= ? AND payment_date <= ?;",
        (f"{start_ym}-01", f"{end_ym}-31"),
    ).fetchone()["c"]
    conn.close()

    fin_data = [
        ["Item", "Valor"],
        ["Total recebido no período", cents_to_brl(recebido)],
        ["Total estornado no período", cents_to_brl(estornado)],
        ["Quantidade de pagamentos", str(qtd_pagamentos)],
    ]
    t2 = Table(fin_data, colWidths=[9 * cm, 6 * cm])
    t2.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), ACCENT),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9.5),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#D8DCD2")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, ACCENT_LIGHT]),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(t2)

    # ---------- INADIMPLÊNCIA ----------
    story.append(Paragraph("Alunos inadimplentes atualmente", ss["SecaoTitulo"]))
    inadimplentes_rows = [["Aluno", "Situação", "Dias em atraso", "Próxima competência"]]
    for s in students_service.list_students(status="ativo"):
        status = finance_service.compute_financial_status(s["id"])
        if status["status"] in ("atraso", "inadimplente", "inativo_por_inadimplencia"):
            inadimplentes_rows.append([
                s["full_name"], finance_service.STATUS_LABELS[status["status"]],
                str(status["dias_atraso"]), status["proxima_competencia"] or "-",
            ])
    if len(inadimplentes_rows) == 1:
        story.append(Paragraph("Nenhum aluno inadimplente no momento.", ss["Corpo"]))
    else:
        t3 = Table(inadimplentes_rows, colWidths=[6 * cm, 4.5 * cm, 2.5 * cm, 2.5 * cm])
        t3.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), ALERT),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#D8DCD2")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F5DED9")]),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ]))
        story.append(t3)

    # ---------- LISTA DE ALUNOS (opcional) ----------
    if include_student_list:
        story.append(PageBreak())
        story.append(Paragraph("Alunos ativos", ss["SecaoTitulo"]))
        alunos_rows = [["Nome", "Telefone", "Plano", "Valor", "Situação"]]
        for s in students_service.list_students(status="ativo"):
            plan = finance_service.get_current_plan(s["id"])
            status = finance_service.compute_financial_status(s["id"])
            alunos_rows.append([
                s["full_name"], s["phone"] or "-",
                plan["plan_name"] if plan else "-",
                cents_to_brl(plan["value_cents"]) if plan else "-",
                finance_service.STATUS_LABELS[status["status"]],
            ])
        t4 = Table(alunos_rows, colWidths=[5 * cm, 3 * cm, 3 * cm, 2.5 * cm, 2.5 * cm])
        t4.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), ACCENT),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8.5),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#D8DCD2")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, ACCENT_LIGHT]),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(t4)

    doc.build(story, onFirstPage=_header_footer, onLaterPages=_header_footer)
    log_info(f"Relatório PDF gerado: {filename}")
    return filepath
