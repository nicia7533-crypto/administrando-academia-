"""
money.py
--------
Helpers monetários (seção 22). Todo valor é INTEGER em centavos internamente.
Esta é a ÚNICA função que deve formatar dinheiro para exibição no sistema
inteiro — dashboard, relatórios e PDF usam esta mesma função (seção 90).
"""


def cents_to_brl(cents: int) -> str:
    cents = int(cents or 0)
    negative = cents < 0
    cents = abs(cents)
    reais, centavos = divmod(cents, 100)
    formatted = f"{reais:,}".replace(",", ".")
    result = f"R$ {formatted},{centavos:02d}"
    return f"-{result}" if negative else result


def brl_str_to_cents(value: str) -> int:
    """Converte um texto digitado pelo usuário (ex: '150,00' ou '150.00' ou '150')
    para centavos inteiros, sem nunca passar por float."""
    value = value.strip().replace("R$", "").strip()
    if "," in value:
        reais_part, cent_part = value.rsplit(",", 1)
        reais_part = reais_part.replace(".", "")
        cent_part = (cent_part + "00")[:2]
    else:
        parts = value.split(".")
        if len(parts) == 2 and len(parts[1]) == 2:
            reais_part, cent_part = parts
        else:
            reais_part, cent_part = value.replace(".", ""), "00"
    reais_part = reais_part.replace(".", "") or "0"
    return int(reais_part) * 100 + int(cent_part)
