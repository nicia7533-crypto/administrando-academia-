-- =====================================================================
-- Migration 001 - Estrutura inicial do Corpo Dinâmico
-- =====================================================================
-- Convenções obrigatórias deste projeto (não mudar sem nova migration):
--   * Todo valor monetário é INTEGER em CENTAVOS (nunca REAL/FLOAT).
--   * Toda data é TEXT em formato ISO 'YYYY-MM-DD' (ou 'YYYY-MM-DD HH:MM:SS').
--   * Toda competência de mensalidade é TEXT em formato 'YYYY-MM'.
--   * Nada é apagado fisicamente de tabelas financeiras ou de alunos:
--     usa-se status/ativo e tabelas de estorno, nunca DELETE.
-- =====================================================================

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------
-- USUÁRIOS E PAPÉIS (seções 31-35)
-- ---------------------------------------------------------------------
CREATE TABLE users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    username        TEXT NOT NULL UNIQUE,
    password_hash   TEXT NOT NULL,          -- hash (nunca a senha em si)
    password_salt   TEXT NOT NULL,          -- salt único por usuário
    role            TEXT NOT NULL CHECK (role IN ('admin', 'professor')),
    full_name       TEXT NOT NULL,
    active          INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
    failed_attempts INTEGER NOT NULL DEFAULT 0,
    locked_until    TEXT,                   -- ISO datetime; bloqueio por tentativas
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);

-- ---------------------------------------------------------------------
-- CONFIGURAÇÕES (seção 30 e 76 - regras configuráveis, nada fixo no código)
-- ---------------------------------------------------------------------
CREATE TABLE settings (
    key         TEXT PRIMARY KEY,
    value       TEXT NOT NULL,
    updated_at  TEXT NOT NULL,
    updated_by  INTEGER REFERENCES users(id)
);

-- ---------------------------------------------------------------------
-- ALUNOS (seções 17-21, 41-42)
-- ---------------------------------------------------------------------
CREATE TABLE students (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,   -- ID interno permanente
    full_name       TEXT NOT NULL,
    phone           TEXT,
    address         TEXT,
    birth_date      TEXT,                                -- 'YYYY-MM-DD'
    notes           TEXT,
    status          TEXT NOT NULL DEFAULT 'ativo'
                        CHECK (status IN ('ativo','inativo','encerrado')),
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);
CREATE INDEX idx_students_name   ON students(full_name);
CREATE INDEX idx_students_phone  ON students(phone);
CREATE INDEX idx_students_status ON students(status);

-- Linha do tempo / histórico do aluno (seções 20, 45)
CREATE TABLE student_events (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id   INTEGER NOT NULL REFERENCES students(id),
    event_type   TEXT NOT NULL CHECK (event_type IN (
                     'cadastro','avaliacao','plano_alterado','pagamento',
                     'atraso','inadimplencia','inatividade','encerramento',
                     'reativacao','observacao','correcao_financeira')),
    event_date   TEXT NOT NULL,
    details      TEXT,                 -- JSON com detalhes específicos do evento
    created_by   INTEGER REFERENCES users(id),
    created_at   TEXT NOT NULL
);
CREATE INDEX idx_events_student ON student_events(student_id, event_date);

-- ---------------------------------------------------------------------
-- PLANOS (seção 43, 76 - valores configuráveis pelo administrador)
-- ---------------------------------------------------------------------
CREATE TABLE plans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL UNIQUE,
    default_value_cents INTEGER NOT NULL CHECK (default_value_cents >= 0),
    active          INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
    created_at      TEXT NOT NULL
);

-- Vínculo aluno-plano vigente (permite valor negociado individual)
CREATE TABLE student_plans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id      INTEGER NOT NULL REFERENCES students(id),
    plan_id         INTEGER NOT NULL REFERENCES plans(id),
    value_cents     INTEGER NOT NULL CHECK (value_cents >= 0),
    due_day         INTEGER NOT NULL CHECK (due_day BETWEEN 1 AND 28),
    start_date      TEXT NOT NULL,       -- a partir de quando vale este plano/valor
    end_date        TEXT,                -- NULL = vigente
    created_at      TEXT NOT NULL,
    created_by      INTEGER REFERENCES users(id)
);
CREATE INDEX idx_student_plans_student ON student_plans(student_id, start_date);

-- ---------------------------------------------------------------------
-- PAGAMENTOS (seções 24-28)
-- ---------------------------------------------------------------------
CREATE TABLE payments (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id      INTEGER NOT NULL REFERENCES students(id),
    amount_cents    INTEGER NOT NULL CHECK (amount_cents > 0),
    payment_date    TEXT NOT NULL,        -- quando o dinheiro entrou (seção 28)
    payment_method  TEXT NOT NULL CHECK (payment_method IN
                        ('dinheiro','pix','cartao_debito','cartao_credito','outro')),
    note            TEXT,
    operation_uid   TEXT NOT NULL UNIQUE, -- chave de idempotência (seção 25)
    created_by      INTEGER NOT NULL REFERENCES users(id),
    created_at      TEXT NOT NULL,
    reversed        INTEGER NOT NULL DEFAULT 0 CHECK (reversed IN (0,1)),
    reversed_reason TEXT,
    reversed_by     INTEGER REFERENCES users(id),
    reversed_at     TEXT
);
CREATE INDEX idx_payments_student ON payments(student_id, payment_date);
CREATE INDEX idx_payments_uid     ON payments(operation_uid);

-- Competências quitadas por cada pagamento (seções 27-28)
-- Um pagamento de R$600 pode gerar 4 linhas aqui (uma por mês quitado).
CREATE TABLE payment_competencies (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    payment_id      INTEGER NOT NULL REFERENCES payments(id),
    student_id      INTEGER NOT NULL REFERENCES students(id),
    competency      TEXT NOT NULL,        -- 'YYYY-MM'
    amount_cents    INTEGER NOT NULL CHECK (amount_cents > 0),
    UNIQUE (student_id, competency)       -- uma competência não pode ser quitada 2x
);
CREATE INDEX idx_paycomp_student ON payment_competencies(student_id, competency);

-- ---------------------------------------------------------------------
-- AUDITORIA (seção 58) - nunca registra senha
-- ---------------------------------------------------------------------
CREATE TABLE audit_log (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER REFERENCES users(id),
    action       TEXT NOT NULL,
    entity       TEXT NOT NULL,
    entity_id    INTEGER,
    old_value    TEXT,
    new_value    TEXT,
    reason       TEXT,
    created_at   TEXT NOT NULL
);
CREATE INDEX idx_audit_entity ON audit_log(entity, entity_id);
CREATE INDEX idx_audit_date   ON audit_log(created_at);

-- ---------------------------------------------------------------------
-- BACKUPS (seções 54-57)
-- ---------------------------------------------------------------------
CREATE TABLE backup_log (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    filename     TEXT NOT NULL,
    checksum     TEXT NOT NULL,
    created_at   TEXT NOT NULL,
    created_by   INTEGER REFERENCES users(id),
    restored_at  TEXT,
    restored_by  INTEGER REFERENCES users(id)
);

-- ---------------------------------------------------------------------
-- Controle de versão do schema (seção 60, 77)
-- ---------------------------------------------------------------------
CREATE TABLE schema_migrations (
    version      INTEGER PRIMARY KEY,
    applied_at   TEXT NOT NULL
);
