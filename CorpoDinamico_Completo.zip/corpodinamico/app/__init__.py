# Pacote principal do Corpo Dinâmico.
