"""
backup_service.py
------------------
Backup e restauração (seções 54-57).

- Backup nunca sobrescreve o anterior (nome com data/hora).
- Todo backup tem checksum SHA-256 registrado, e é validado antes de restaurar.
- Antes de restaurar, o sistema faz backup do estado ATUAL primeiro
  (proteção contra "restaurei errado e perdi tudo").
"""

import os
import shutil
import zipfile
import hashlib
import json
from datetime import datetime, timezone

from app.paths import BACKUPS_DIR, DATABASE_PATH, DATABASE_DIR, CONFIG_DIR, ensure_all_dirs
from app.db import get_connection, transaction, check_integrity
from app.logger import log_info, log_error, log_warning

APP_VERSION = "1.0.0"
DB_VERSION = 1
MANIFEST_NAME = "manifest.json"
DB_ENTRY_NAME = "corpodinamico.db"


def _now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S")


def _sha256_of_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


class BackupError(Exception):
    pass


def reconcile_backup_log(user_id: int | None = None) -> int:
    """
    Corrige uma inconsistência real: se o banco for restaurado para um
    estado anterior, a tabela `backup_log` volta a como estava naquele
    momento — mas os arquivos .zip de backups feitos DEPOIS continuam
    fisicamente na pasta backups/. Sem isso, esses backups ficariam
    "invisíveis" para o administrador mesmo existindo em disco.

    Esta função varre a pasta de backups e recadastra no banco qualquer
    .zip válido que não esteja registrado. Roda automaticamente após
    toda restauração, e também pode ser chamada na inicialização.
    Retorna quantos backups foram recuperados.
    """
    ensure_all_dirs()
    conn = get_connection()
    known = {r["filename"] for r in conn.execute("SELECT filename FROM backup_log;").fetchall()}
    conn.close()

    recovered = 0
    for name in sorted(os.listdir(BACKUPS_DIR)):
        if not name.lower().endswith(".zip") or name in known:
            continue
        full_path = os.path.join(BACKUPS_DIR, name)
        try:
            manifest = validate_backup_file(full_path)
        except BackupError as e:
            log_warning(f"Backup órfão '{name}' ignorado na reconciliação (inválido): {e}")
            continue

        checksum = _sha256_of_file(full_path)
        created_at = manifest.get("created_at", _now_iso())
        with transaction() as conn:
            conn.execute(
                "INSERT INTO backup_log (filename, checksum, created_at, created_by) VALUES (?, ?, ?, ?);",
                (name, checksum, created_at, user_id),
            )
        recovered += 1
        log_info(f"Backup órfão recuperado no cadastro: {name}")

    return recovered


def create_backup(user_id: int | None, reason: str = "manual") -> dict:
    ensure_all_dirs()

    # checkpoint do WAL antes de copiar, garante que o arquivo .db tenha
    # tudo que foi commitado até agora (seção 52)
    conn = get_connection()
    conn.execute("PRAGMA wal_checkpoint(FULL);")
    conn.close()

    ok, detail = check_integrity()
    if not ok:
        raise BackupError(f"O banco não passou na verificação de integridade ({detail}). "
                           f"Backup NÃO foi criado para evitar salvar dados corrompidos.")

    stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"Backup_CorpoDinamico_{stamp}.zip"
    filepath = os.path.join(BACKUPS_DIR, filename)

    # Garantia extra: mesmo que dois backups caiam no mesmo segundo (ex.:
    # backup de segurança automático rodando logo antes de uma restauração),
    # NUNCA sobrescreve um backup existente — sempre gera nome único.
    if os.path.exists(filepath):
        counter = 2
        while True:
            candidate = os.path.join(BACKUPS_DIR, f"Backup_CorpoDinamico_{stamp}_{counter}.zip")
            if not os.path.exists(candidate):
                filepath = candidate
                filename = os.path.basename(candidate)
                break
            counter += 1

    db_checksum = _sha256_of_file(DATABASE_PATH)
    manifest = {
        "app": "CorpoDinamico",
        "app_version": APP_VERSION,
        "db_version": DB_VERSION,
        "created_at": _now_iso(),
        "reason": reason,
        "db_checksum_sha256": db_checksum,
    }

    with zipfile.ZipFile(filepath, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(DATABASE_PATH, arcname=DB_ENTRY_NAME)
        zf.writestr(MANIFEST_NAME, json.dumps(manifest, ensure_ascii=False, indent=2))

    zip_checksum = _sha256_of_file(filepath)

    with transaction() as conn:
        conn.execute(
            "INSERT INTO backup_log (filename, checksum, created_at, created_by) VALUES (?, ?, ?, ?);",
            (filename, zip_checksum, _now_iso(), user_id),
        )
        conn.execute(
            """INSERT INTO audit_log (user_id, action, entity, new_value, created_at)
               VALUES (?, 'criar_backup', 'backup', ?, ?)""",
            (user_id, filename, _now_iso()),
        )

    log_info(f"Backup criado: {filename}")
    return {"filename": filename, "path": filepath, "checksum": zip_checksum, "created_at": manifest["created_at"]}


def list_backups() -> list[dict]:
    conn = get_connection()
    rows = conn.execute("SELECT * FROM backup_log ORDER BY created_at DESC;").fetchall()
    conn.close()
    result = []
    for r in rows:
        path = os.path.join(BACKUPS_DIR, r["filename"])
        result.append({
            "id": r["id"], "filename": r["filename"], "checksum": r["checksum"],
            "created_at": r["created_at"], "restored_at": r["restored_at"],
            "exists_on_disk": os.path.exists(path),
            "size_kb": round(os.path.getsize(path) / 1024, 1) if os.path.exists(path) else None,
        })
    return result


def validate_backup_file(filepath: str) -> dict:
    """Valida estrutura, manifesto e checksum ANTES de considerar o
    arquivo restaurável (seção 57) — nunca confia só porque o arquivo existe."""
    if not os.path.exists(filepath):
        raise BackupError("Arquivo de backup não encontrado.")
    if not zipfile.is_zipfile(filepath):
        raise BackupError("Este arquivo não é um backup válido (não é um .zip reconhecível).")

    with zipfile.ZipFile(filepath, "r") as zf:
        names = zf.namelist()
        if DB_ENTRY_NAME not in names or MANIFEST_NAME not in names:
            raise BackupError("Este arquivo não contém a estrutura esperada de um backup do Corpo Dinâmico.")

        bad_file = zf.testzip()
        if bad_file is not None:
            raise BackupError(f"O arquivo de backup está corrompido (falha em {bad_file}).")

        manifest = json.loads(zf.read(MANIFEST_NAME))
        if manifest.get("app") != "CorpoDinamico":
            raise BackupError("Este backup não pertence ao sistema Corpo Dinâmico.")

        # extrai temporariamente o .db pra conferir o checksum interno
        tmp_dir = os.path.join(BACKUPS_DIR, "_tmp_validacao")
        os.makedirs(tmp_dir, exist_ok=True)
        try:
            zf.extract(DB_ENTRY_NAME, tmp_dir)
            extracted_db = os.path.join(tmp_dir, DB_ENTRY_NAME)
            checksum_now = _sha256_of_file(extracted_db)
            if checksum_now != manifest.get("db_checksum_sha256"):
                raise BackupError("O checksum do banco dentro do backup não confere — "
                                   "o arquivo pode estar corrompido ou foi alterado.")
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

    return manifest


def restore_backup(filepath: str, user_id: int) -> dict:
    """
    Fluxo completo de restauração (seção 56):
    validar -> avisar impacto -> backup do estado atual -> restaurar -> validar -> auditar
    """
    manifest = validate_backup_file(filepath)  # 1, 2, 3

    # backup de segurança do estado ATUAL antes de sobrescrever (seção 55/56 passo 6)
    safety = create_backup(user_id, reason="pre_restauracao_automatico")
    log_info(f"Backup de segurança criado antes da restauração: {safety['filename']}")

    tmp_dir = os.path.join(BACKUPS_DIR, "_tmp_restore")
    os.makedirs(tmp_dir, exist_ok=True)
    try:
        with zipfile.ZipFile(filepath, "r") as zf:
            zf.extract(DB_ENTRY_NAME, tmp_dir)
        extracted_db = os.path.join(tmp_dir, DB_ENTRY_NAME)

        # troca atômica: escreve num arquivo temporário no MESMO disco e
        # substitui de uma vez (os.replace é atômico no mesmo filesystem)
        final_tmp = DATABASE_PATH + ".restoring"
        shutil.copy2(extracted_db, final_tmp)
        # remove WAL/SHM antigos pra não misturar com o banco restaurado
        for suffix in ("-wal", "-shm"):
            leftover = DATABASE_PATH + suffix
            if os.path.exists(leftover):
                os.remove(leftover)
        os.replace(final_tmp, DATABASE_PATH)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

    ok, detail = check_integrity()
    if not ok:
        raise BackupError(
            f"ATENÇÃO: após a restauração, o banco não passou na verificação de integridade "
            f"({detail}). Um backup do estado anterior foi salvo em '{safety['filename']}' "
            f"e pode ser usado para reverter esta operação."
        )

    now = _now_iso()
    with transaction() as conn:
        conn.execute(
            "UPDATE backup_log SET restored_at=?, restored_by=? WHERE filename=?;",
            (now, user_id, os.path.basename(filepath)),
        )
        conn.execute(
            """INSERT INTO audit_log (user_id, action, entity, new_value, reason, created_at)
               VALUES (?, 'restaurar_backup', 'backup', ?, ?, ?)""",
            (user_id, os.path.basename(filepath),
             f"backup de seguranca pre-restauracao: {safety['filename']}", now),
        )

    log_info(f"Backup restaurado com sucesso a partir de {os.path.basename(filepath)}")
    recovered = reconcile_backup_log(user_id)
    if recovered:
        log_info(f"{recovered} backup(s) órfão(s) recuperado(s) no cadastro após a restauração.")
    return {"restored_from": os.path.basename(filepath), "safety_backup": safety["filename"], "manifest": manifest}
