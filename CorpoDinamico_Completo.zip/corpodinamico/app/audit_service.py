"""
audit_service.py
------------------
Consulta da trilha de auditoria (seção 58). A gravação acontece dentro
de cada serviço (auth, students_service, finance_service, backup_service,
settings_service) — aqui só concentramos a consulta para a tela de Auditoria.
"""

from app.db import get_connection


def list_audit(limit: int = 200, entity: str | None = None, user_id: int | None = None) -> list[dict]:
    conn = get_connection()
    q = """SELECT a.*, u.username, u.full_name FROM audit_log a
           LEFT JOIN users u ON u.id = a.user_id WHERE 1=1"""
    params = []
    if entity:
        q += " AND a.entity = ?"
        params.append(entity)
    if user_id:
        q += " AND a.user_id = ?"
        params.append(user_id)
    q += " ORDER BY a.created_at DESC, a.id DESC LIMIT ?;"
    params.append(limit)
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]
