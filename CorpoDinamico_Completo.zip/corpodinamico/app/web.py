"""
web.py
------
Interface web local (servida em 127.0.0.1, sem depender de internet).
Roda dentro da janela do pywebview (main.py) ou em qualquer navegador,
mas nunca é publicada para fora da máquina.

Regra de ouro (seção 35): a permissão é checada em CADA rota, no servidor.
Esconder botão na tela não é segurança — cada função abaixo confere de
novo quem está logado e qual o papel, antes de fazer qualquer coisa.
"""

import os
import functools
import uuid
from datetime import datetime

from flask import (
    Flask, render_template, request, redirect, url_for, session, flash,
    send_file, abort, jsonify
)

from app import auth, students_service, finance_service, settings_service
from app import dashboard_service, backup_service, audit_service, system_health, reports_pdf
from app.money import cents_to_brl, brl_str_to_cents
from app.paths import ASSETS_DIR
from app.logger import log_error


def create_app() -> Flask:
    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.secret_key = _get_or_create_secret_key()
    app.jinja_env.filters["brl"] = cents_to_brl

    # -------------------------------------------------------------
    # Autenticação / decorators de permissão
    # -------------------------------------------------------------
    def login_required(view):
        @functools.wraps(view)
        def wrapped(*args, **kwargs):
            if not auth.has_any_user():
                return redirect(url_for("setup"))
            if "user_id" not in session:
                return redirect(url_for("login"))
            return view(*args, **kwargs)
        return wrapped

    def admin_required(view):
        @functools.wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            if session.get("role") != "admin":
                abort(403)
            return view(*args, **kwargs)
        return wrapped

    @app.context_processor
    def inject_globals():
        return {
            "current_user": {
                "id": session.get("user_id"),
                "username": session.get("username"),
                "role": session.get("role"),
                "full_name": session.get("full_name"),
            } if "user_id" in session else None,
            "academia_nome": _safe_setting("academia_nome", "Corpo Dinâmico Academia"),
        }

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("erro.html", titulo="Acesso negado",
                                mensagem="Você não tem permissão para acessar esta área."), 403

    @app.errorhandler(500)
    def server_error(e):
        log_error("Erro interno não tratado", e)
        return render_template(
            "erro.html", titulo="Não foi possível concluir a operação",
            mensagem="Nenhum dado foi alterado. Verifique e tente novamente."
        ), 500

    # -------------------------------------------------------------
    # Primeira execução / login / logout
    # -------------------------------------------------------------
    @app.route("/setup", methods=["GET", "POST"])
    def setup():
        if auth.has_any_user():
            return redirect(url_for("login"))
        error = None
        if request.method == "POST":
            owner_pass = request.form.get("owner_password", "")
            owner_pass2 = request.form.get("owner_password2", "")
            teacher_user = request.form.get("teacher_username", "professor").strip() or "professor"
            teacher_pass = request.form.get("teacher_password", "")
            if len(owner_pass) < 6 or len(teacher_pass) < 6:
                error = "Cada senha precisa ter pelo menos 6 caracteres."
            elif owner_pass != owner_pass2:
                error = "A confirmação da senha do proprietário não confere."
            else:
                admin_id = auth.create_user("admin", owner_pass, "admin", "Proprietário")
                auth.create_user(teacher_user, teacher_pass, "professor", "Professor(a)")
                settings_service.seed_defaults()
                user = auth.authenticate("admin", owner_pass)
                _login_session(user)
                flash("Sistema configurado com sucesso. Bem-vindo(a)!", "sucesso")
                return redirect(url_for("dashboard"))
        return render_template("setup.html", error=error)

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if not auth.has_any_user():
            return redirect(url_for("setup"))
        error = None
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            try:
                user = auth.authenticate(username, password)
                _login_session(user)
                return redirect(url_for("dashboard"))
            except auth.AccountLocked as e:
                error = f"Conta bloqueada por tentativas excessivas. Tente novamente em {e.minutes_remaining} minuto(s)."
            except auth.AuthError as e:
                error = str(e)
        return render_template("login.html", error=error)

    @app.route("/logout")
    def logout():
        session.clear()
        return redirect(url_for("login"))

    def _login_session(user: dict):
        session["user_id"] = user["id"]
        session["username"] = user["username"]
        session["role"] = user["role"]
        session["full_name"] = user["full_name"]

    # -------------------------------------------------------------
    # Painel (somente admin — dados financeiros consolidados)
    # -------------------------------------------------------------
    @app.route("/")
    @login_required
    def dashboard():
        if session["role"] != "admin":
            return redirect(url_for("alunos_lista"))
        overview = dashboard_service.overview()
        evolucao = dashboard_service.revenue_evolution()
        health = system_health.get_health()
        return render_template("dashboard.html", overview=overview, evolucao=evolucao, health=health)

    # -------------------------------------------------------------
    # Alunos (ambos os papéis — professor com visão discreta)
    # -------------------------------------------------------------
    @app.route("/alunos")
    @login_required
    def alunos_lista():
        status = request.args.get("status") or None
        search = request.args.get("q") or None
        alunos = students_service.list_students(status=status, search=search)
        is_admin = session["role"] == "admin"
        for a in alunos:
            result = finance_service.compute_financial_status(a["id"])
            a["situacao"] = result["status"]
            a["situacao_label"] = finance_service.STATUS_LABELS[result["status"]]
        return render_template("alunos_lista.html", alunos=alunos, status=status, search=search or "",
                                is_admin=is_admin)

    @app.route("/alunos/novo", methods=["GET", "POST"])
    @admin_required
    def alunos_novo():
        planos = finance_service.list_plans()
        error = None
        duplicates = None
        if request.method == "POST":
            try:
                force = request.form.get("confirmar_novo") == "1"
                value_cents = brl_str_to_cents(request.form.get("valor", "0"))
                student_id = students_service.create_student(
                    full_name=request.form["full_name"].strip(),
                    phone=request.form.get("phone", "").strip(),
                    address=request.form.get("address", "").strip(),
                    birth_date=request.form.get("birth_date") or None,
                    notes=request.form.get("notes", "").strip(),
                    plan_id=int(request.form["plan_id"]),
                    value_cents=value_cents,
                    due_day=int(request.form["due_day"]),
                    start_date=request.form["start_date"],
                    evaluation_date=request.form.get("evaluation_date") or None,
                    user_id=session["user_id"],
                    force_despite_duplicate=force,
                )
                flash("Aluno cadastrado com sucesso.", "sucesso")
                return redirect(url_for("aluno_detalhe", student_id=student_id))
            except students_service.DuplicateWarning as e:
                duplicates = e.matches
            except (ValueError, KeyError) as e:
                error = str(e)
        return render_template("aluno_form.html", planos=planos, error=error, duplicates=duplicates,
                                today=datetime.now().strftime("%Y-%m-%d"))

    @app.route("/alunos/<int:student_id>")
    @login_required
    def aluno_detalhe(student_id):
        student = students_service.get_student(student_id)
        if student is None:
            abort(404)
        status = finance_service.compute_financial_status(student_id)
        paid_until = finance_service.get_paid_until(student_id)
        conn_payments = _list_payments(student_id)
        is_admin = session["role"] == "admin"
        return render_template("aluno_detalhe.html", student=student, status=status,
                                status_label=finance_service.STATUS_LABELS[status["status"]],
                                paid_until=paid_until, payments=conn_payments, is_admin=is_admin,
                                new_uid=str(uuid.uuid4()))

    def _list_payments(student_id):
        from app.db import get_connection
        conn = get_connection()
        rows = conn.execute(
            "SELECT * FROM payments WHERE student_id=? ORDER BY payment_date DESC, id DESC;",
            (student_id,),
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    @app.route("/alunos/<int:student_id>/editar", methods=["GET", "POST"])
    @admin_required
    def aluno_editar(student_id):
        student = students_service.get_student(student_id)
        if student is None:
            abort(404)
        if request.method == "POST":
            students_service.update_student(
                student_id, request.form["full_name"].strip(), request.form.get("phone", "").strip(),
                request.form.get("address", "").strip(), request.form.get("birth_date") or None,
                request.form.get("notes", "").strip(), session["user_id"],
            )
            flash("Dados atualizados.", "sucesso")
            return redirect(url_for("aluno_detalhe", student_id=student_id))
        return render_template("aluno_editar.html", student=student)

    @app.route("/alunos/<int:student_id>/encerrar", methods=["POST"])
    @admin_required
    def aluno_encerrar(student_id):
        motivo = request.form.get("motivo", "").strip() or "Não informado"
        students_service.close_student(student_id, motivo, session["user_id"])
        flash("Aluno encerrado. O histórico foi preservado.", "sucesso")
        return redirect(url_for("aluno_detalhe", student_id=student_id))

    @app.route("/alunos/<int:student_id>/reativar", methods=["GET", "POST"])
    @admin_required
    def aluno_reativar(student_id):
        student = students_service.get_student(student_id)
        planos = finance_service.list_plans()
        if request.method == "POST":
            students_service.reactivate_student(
                student_id=student_id, plan_id=int(request.form["plan_id"]),
                value_cents=brl_str_to_cents(request.form.get("valor", "0")),
                due_day=int(request.form["due_day"]), start_date=request.form["start_date"],
                evaluation_date=request.form.get("evaluation_date") or None,
                fee_cents=brl_str_to_cents(request.form.get("taxa", "0")), user_id=session["user_id"],
            )
            flash("Aluno reativado com sucesso — histórico anterior preservado.", "sucesso")
            return redirect(url_for("aluno_detalhe", student_id=student_id))
        return render_template("aluno_reativar.html", student=student, planos=planos,
                                today=datetime.now().strftime("%Y-%m-%d"))

    # -------------------------------------------------------------
    # Financeiro (somente admin)
    # -------------------------------------------------------------
    @app.route("/alunos/<int:student_id>/pagamento", methods=["POST"])
    @admin_required
    def registrar_pagamento(student_id):
        try:
            amount_cents = brl_str_to_cents(request.form["valor"])
            result = finance_service.register_payment(
                student_id=student_id, amount_cents=amount_cents,
                payment_date=request.form["payment_date"], payment_method=request.form["payment_method"],
                note=request.form.get("note", "").strip(), user_id=session["user_id"],
                operation_uid=request.form.get("operation_uid"),
            )
            if result["already_existed"]:
                flash("Esse pagamento já havia sido registrado — nada foi duplicado.", "aviso")
            else:
                flash(f"Pagamento registrado. Competências quitadas: {', '.join(result['competencies'])}.", "sucesso")
        except finance_service.PaymentError as e:
            flash(str(e), "erro")
        return redirect(url_for("aluno_detalhe", student_id=student_id))

    @app.route("/pagamentos/<int:payment_id>/estornar", methods=["POST"])
    @admin_required
    def estornar_pagamento(payment_id):
        student_id = request.form["student_id"]
        try:
            finance_service.reverse_payment(payment_id, request.form["motivo"], session["user_id"])
            flash("Pagamento estornado. O histórico foi preservado.", "sucesso")
        except finance_service.PaymentError as e:
            flash(str(e), "erro")
        return redirect(url_for("aluno_detalhe", student_id=student_id))

    @app.route("/planos", methods=["GET", "POST"])
    @admin_required
    def planos():
        if request.method == "POST":
            finance_service.create_plan(
                request.form["name"].strip(), brl_str_to_cents(request.form["valor"]), session["user_id"]
            )
            flash("Plano criado.", "sucesso")
            return redirect(url_for("planos"))
        return render_template("planos.html", planos=finance_service.list_plans(active_only=False))

    # -------------------------------------------------------------
    # Relatórios / PDF (somente admin)
    # -------------------------------------------------------------
    @app.route("/relatorios", methods=["GET", "POST"])
    @admin_required
    def relatorios():
        if request.method == "POST":
            path = reports_pdf.generate_period_report(
                request.form["start_ym"], request.form["end_ym"],
                generated_by=session["full_name"],
                include_student_list=request.form.get("incluir_lista") == "1",
            )
            return send_file(path, as_attachment=True, download_name=os.path.basename(path))
        return render_template("relatorios.html", today_ym=datetime.now().strftime("%Y-%m"))

    # -------------------------------------------------------------
    # Backup / Restauração (somente admin)
    # -------------------------------------------------------------
    @app.route("/backup", methods=["GET"])
    @admin_required
    def backup_home():
        return render_template("backup.html", backups=backup_service.list_backups())

    @app.route("/backup/criar", methods=["POST"])
    @admin_required
    def backup_criar():
        try:
            backup_service.create_backup(session["user_id"], reason="manual")
            flash("Backup criado com sucesso.", "sucesso")
        except backup_service.BackupError as e:
            flash(str(e), "erro")
        return redirect(url_for("backup_home"))

    @app.route("/backup/baixar/<path:filename>")
    @admin_required
    def backup_baixar(filename):
        from app.paths import BACKUPS_DIR
        safe_path = os.path.join(BACKUPS_DIR, os.path.basename(filename))
        if not os.path.exists(safe_path):
            abort(404)
        return send_file(safe_path, as_attachment=True, download_name=os.path.basename(safe_path))

    @app.route("/backup/restaurar", methods=["POST"])
    @admin_required
    def backup_restaurar():
        filename = request.form.get("filename")
        uploaded = request.files.get("arquivo")
        try:
            if uploaded and uploaded.filename:
                from app.paths import BACKUPS_DIR
                tmp_path = os.path.join(BACKUPS_DIR, f"_upload_{uuid.uuid4().hex}.zip")
                uploaded.save(tmp_path)
                result = backup_service.restore_backup(tmp_path, session["user_id"])
                os.remove(tmp_path)
            elif filename:
                from app.paths import BACKUPS_DIR
                path = os.path.join(BACKUPS_DIR, os.path.basename(filename))
                result = backup_service.restore_backup(path, session["user_id"])
            else:
                flash("Selecione um backup da lista ou envie um arquivo.", "erro")
                return redirect(url_for("backup_home"))
            flash(f"Backup restaurado com sucesso. Um backup do estado anterior foi salvo como "
                  f"'{result['safety_backup']}', caso seja necessário reverter.", "sucesso")
        except backup_service.BackupError as e:
            flash(str(e), "erro")
        return redirect(url_for("backup_home"))

    # -------------------------------------------------------------
    # Auditoria / Saúde / Configurações (somente admin)
    # -------------------------------------------------------------
    @app.route("/auditoria")
    @admin_required
    def auditoria():
        return render_template("auditoria.html", registros=audit_service.list_audit())

    @app.route("/saude")
    @admin_required
    def saude():
        return render_template("saude.html", health=system_health.get_health())

    @app.route("/configuracoes", methods=["GET", "POST"])
    @admin_required
    def configuracoes():
        if request.method == "POST":
            for key in ("academia_nome", "tolerancia_dias", "atraso_dias",
                        "inadimplencia_dias", "inatividade_dias", "min_espaco_livre_mb"):
                if key in request.form:
                    settings_service.set_value(key, request.form[key], session["user_id"])
            flash("Configurações salvas.", "sucesso")
            return redirect(url_for("configuracoes"))
        return render_template("configuracoes.html", settings=settings_service.get_all())

    @app.route("/minha-senha", methods=["GET", "POST"])
    @login_required
    def minha_senha():
        error = None
        if request.method == "POST":
            nova = request.form.get("nova_senha", "")
            confirma = request.form.get("confirma_senha", "")
            if nova != confirma:
                error = "As senhas não conferem."
            else:
                try:
                    auth.change_password(session["user_id"], nova, session["user_id"])
                    flash("Senha alterada com sucesso.", "sucesso")
                    return redirect(url_for("dashboard"))
                except ValueError as e:
                    error = str(e)
        return render_template("minha_senha.html", error=error)

    return app


def _get_or_create_secret_key() -> str:
    from app.paths import CONFIG_DIR, ensure_all_dirs
    ensure_all_dirs()
    key_path = os.path.join(CONFIG_DIR, "secret.key")
    if os.path.exists(key_path):
        with open(key_path, "r") as f:
            return f.read().strip()
    key = uuid.uuid4().hex + uuid.uuid4().hex
    with open(key_path, "w") as f:
        f.write(key)
    return key


def _safe_setting(key, default):
    try:
        return settings_service.get(key)
    except Exception:
        return default
