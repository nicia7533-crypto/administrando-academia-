"""
finance_service.py
-------------------
Regras financeiras (seções 22-30, 40, 89-90).

Este módulo é a ÚNICA fonte da verdade financeira do sistema: dashboard,
relatórios e PDF sempre chamam estas mesmas funções — nunca recalculam
por conta própria (seção 90).

Conceitos centrais:
  - Dinheiro sempre em centavos (inteiro), nunca float.
  - "Data do pagamento" (quando o dinheiro entrou) é separada de
    "competência" (mês que foi quitado) — seção 28.
  - Idempotência: um mesmo `operation_uid` nunca gera dois pagamentos,
    mesmo com duplo clique ou reenvio (seção 25).
  - Estorno preserva histórico; nunca apaga silenciosamente (seção 26).
  - Status de inadimplência é sempre calculado a partir das mesmas regras
    configuráveis (settings), nunca fixo no código (seção 30).
"""

import uuid
from datetime import datetime, date, timezone

from app.db import transaction, get_connection
from app import settings_service
from app.logger import log_info, log_warning


def _now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S")


def _today() -> date:
    return datetime.now().date()


def _add_months(y: int, m: int, delta: int) -> tuple[int, int]:
    idx = (y * 12 + (m - 1)) + delta
    return idx // 12, idx % 12 + 1


def _ym_str(y: int, m: int) -> str:
    return f"{y:04d}-{m:02d}"


def new_operation_uid() -> str:
    return str(uuid.uuid4())


# ---------------------------------------------------------------------
# Planos (seção 43, 76)
# ---------------------------------------------------------------------
def create_plan(name: str, default_value_cents: int, user_id: int) -> int:
    now = _now_iso()
    with transaction() as conn:
        cur = conn.execute(
            "INSERT INTO plans (name, default_value_cents, active, created_at) VALUES (?, ?, 1, ?);",
            (name, default_value_cents, now),
        )
        plan_id = cur.lastrowid
        conn.execute(
            """INSERT INTO audit_log (user_id, action, entity, entity_id, new_value, created_at)
               VALUES (?, 'criar_plano', 'plans', ?, ?, ?)""",
            (user_id, plan_id, f"{name} / {default_value_cents}", now),
        )
    return plan_id


def list_plans(active_only: bool = True) -> list[dict]:
    conn = get_connection()
    q = "SELECT * FROM plans"
    if active_only:
        q += " WHERE active=1"
    q += " ORDER BY name;"
    rows = conn.execute(q).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------
# Competências (seções 27-28)
# ---------------------------------------------------------------------
def get_paid_competencies(student_id: int) -> set:
    conn = get_connection()
    rows = conn.execute(
        """SELECT pc.competency FROM payment_competencies pc
           JOIN payments p ON p.id = pc.payment_id
           WHERE pc.student_id=? AND p.reversed=0;""",
        (student_id,),
    ).fetchall()
    conn.close()
    return {r["competency"] for r in rows}


def get_current_plan(student_id: int, conn=None) -> dict | None:
    own_conn = conn is None
    if own_conn:
        conn = get_connection()
    row = conn.execute(
        """SELECT sp.*, p.name as plan_name FROM student_plans sp
           JOIN plans p ON p.id = sp.plan_id
           WHERE sp.student_id=? AND sp.end_date IS NULL
           ORDER BY sp.start_date DESC LIMIT 1;""",
        (student_id,),
    ).fetchone()
    if own_conn:
        conn.close()
    return dict(row) if row else None


def get_next_due_competency(student_id: int) -> str | None:
    """Primeira competência (mês) ainda não quitada, a partir do início do
    plano vigente. Retorna None se o aluno não tem plano ativo."""
    plan = get_current_plan(student_id)
    if plan is None:
        return None
    paid = get_paid_competencies(student_id)
    y, m = map(int, plan["start_date"][:7].split("-"))
    ym = _ym_str(y, m)
    # limite de segurança: no máximo 600 meses (50 anos) pra nunca travar
    for _ in range(600):
        if ym not in paid:
            return ym
        y, m = _add_months(y, m, 1)
        ym = _ym_str(y, m)
    return None


def get_paid_until(student_id: int) -> str | None:
    """Última competência paga de forma contínua desde o início do plano
    (seção 27: 'PAGO ATÉ: DD/MM/AAAA')."""
    next_due = get_next_due_competency(student_id)
    plan = get_current_plan(student_id)
    if plan is None:
        return None
    if next_due is None:
        return "em dia (sem pendências futuras registradas)"
    y, m = map(int, next_due.split("-"))
    y, m = _add_months(y, m, -1)
    start_y, start_m = map(int, plan["start_date"][:7].split("-"))
    if (y, m) < (start_y, start_m):
        return None  # nada pago ainda
    return _ym_str(y, m)


# ---------------------------------------------------------------------
# Pagamentos (seções 24-28)
# ---------------------------------------------------------------------
class PaymentError(Exception):
    pass


def register_payment(student_id: int, amount_cents: int, payment_date: str,
                      payment_method: str, note: str, user_id: int,
                      operation_uid: str | None = None,
                      competencies: list[str] | None = None) -> dict:
    """
    Registra um pagamento e aloca as competências que ele quita.

    Proteção contra duplo pagamento (seção 25): se `operation_uid` já
    existir no banco, o pagamento NÃO é duplicado — devolve o pagamento
    já existente, de forma transparente (idempotência real).
    """
    if amount_cents <= 0:
        raise PaymentError("O valor do pagamento precisa ser maior que zero.")

    operation_uid = operation_uid or new_operation_uid()

    conn = get_connection()
    existing = conn.execute(
        "SELECT * FROM payments WHERE operation_uid=?;", (operation_uid,)
    ).fetchone()
    conn.close()
    if existing is not None:
        log_warning(f"Pagamento com operation_uid={operation_uid} já existia — "
                    f"duplo envio bloqueado, retornando pagamento original id={existing['id']}.")
        return {"payment_id": existing["id"], "already_existed": True, "competencies": []}

    plan = get_current_plan(student_id)
    if competencies is None:
        if plan is None:
            raise PaymentError("Este aluno não tem plano ativo — informe as competências manualmente.")
        value_cents = plan["value_cents"]
        if value_cents <= 0:
            raise PaymentError("O plano do aluno está com valor zerado.")
        n_months = amount_cents // value_cents
        if n_months == 0:
            raise PaymentError(
                f"O valor informado é menor que uma mensalidade "
                f"({value_cents/100:.2f}). Informe as competências manualmente se for parcial."
            )
        competencies = []
        paid = get_paid_competencies(student_id)
        y, m = map(int, plan["start_date"][:7].split("-"))
        ym = _ym_str(y, m)
        while len(competencies) < n_months:
            if ym not in paid:
                competencies.append(ym)
            y, m = _add_months(y, m, 1)
            ym = _ym_str(y, m)
        amount_per_competency = value_cents
    else:
        if not competencies:
            raise PaymentError("Informe pelo menos uma competência.")
        amount_per_competency = amount_cents // len(competencies)

    now = _now_iso()
    with transaction() as conn:
        already_paid = conn.execute(
            f"""SELECT pc.competency FROM payment_competencies pc
                JOIN payments p ON p.id = pc.payment_id
                WHERE pc.student_id=? AND p.reversed=0 AND pc.competency IN
                ({','.join('?' for _ in competencies)});""",
            [student_id, *competencies],
        ).fetchall()
        if already_paid:
            raise PaymentError(
                "Já existe pagamento para a(s) competência(s): "
                + ", ".join(r["competency"] for r in already_paid)
            )

        cur = conn.execute(
            """INSERT INTO payments (student_id, amount_cents, payment_date, payment_method,
               note, operation_uid, created_by, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (student_id, amount_cents, payment_date, payment_method, note, operation_uid, user_id, now),
        )
        payment_id = cur.lastrowid

        for comp in competencies:
            conn.execute(
                """INSERT INTO payment_competencies (payment_id, student_id, competency, amount_cents)
                   VALUES (?, ?, ?, ?)""",
                (payment_id, student_id, comp, amount_per_competency),
            )

        conn.execute(
            """INSERT INTO student_events (student_id, event_type, event_date, details, created_by, created_at)
               VALUES (?, 'pagamento', ?, ?, ?, ?)""",
            (student_id, payment_date,
             f'{{"payment_id": {payment_id}, "amount_cents": {amount_cents}, "competencias": {competencies}}}',
             user_id, now),
        )
        conn.execute(
            """INSERT INTO audit_log (user_id, action, entity, entity_id, new_value, created_at)
               VALUES (?, 'registrar_pagamento', 'payments', ?, ?, ?)""",
            (user_id, payment_id, f"{amount_cents} centavos / {competencies}", now),
        )

    log_info(f"Pagamento registrado: id={payment_id} aluno={student_id} valor_cents={amount_cents}")
    return {"payment_id": payment_id, "already_existed": False, "competencies": competencies}


def reverse_payment(payment_id: int, reason: str, user_id: int) -> None:
    """Estorno (seção 26): preserva o pagamento original no histórico,
    apenas marca como estornado e libera as competências (voltam a ficar
    em aberto). Nunca é um DELETE."""
    if not reason or not reason.strip():
        raise PaymentError("É obrigatório informar o motivo do estorno.")

    now = _now_iso()
    with transaction() as conn:
        payment = conn.execute("SELECT * FROM payments WHERE id=?;", (payment_id,)).fetchone()
        if payment is None:
            raise PaymentError("Pagamento não encontrado.")
        if payment["reversed"]:
            raise PaymentError("Este pagamento já está estornado.")

        conn.execute(
            """UPDATE payments SET reversed=1, reversed_reason=?, reversed_by=?, reversed_at=?
               WHERE id=?;""",
            (reason, user_id, now, payment_id),
        )
        conn.execute(
            """INSERT INTO student_events (student_id, event_type, event_date, details, created_by, created_at)
               VALUES (?, 'correcao_financeira', ?, ?, ?, ?)""",
            (payment["student_id"], now[:10],
             f'{{"payment_id": {payment_id}, "acao": "estorno", "motivo": {reason!r}}}',
             user_id, now),
        )
        conn.execute(
            """INSERT INTO audit_log (user_id, action, entity, entity_id, old_value, new_value, reason, created_at)
               VALUES (?, 'estornar_pagamento', 'payments', ?, ?, 'estornado', ?, ?)""",
            (user_id, payment_id, f"{payment['amount_cents']} centavos", reason, now),
        )
    log_info(f"Pagamento estornado: id={payment_id} motivo={reason!r}")


# ---------------------------------------------------------------------
# Status de inadimplência — FONTE ÚNICA (seções 29-30, 90)
# ---------------------------------------------------------------------
STATUS_LABELS = {
    "sem_plano": "Sem plano ativo",
    "em_dia": "Em dia",
    "atraso": "Em atraso",
    "inadimplente": "Inadimplente",
    "inativo_por_inadimplencia": "Inativo por inadimplência",
    "encerrado": "Encerrado",
    "inativo": "Inativo",
}


def compute_financial_status(student_id: int, as_of: date | None = None) -> dict:
    as_of = as_of or _today()

    conn = get_connection()
    student = conn.execute("SELECT status FROM students WHERE id=?;", (student_id,)).fetchone()
    conn.close()
    if student is None:
        raise ValueError("Aluno não encontrado.")
    if student["status"] == "encerrado":
        return {"status": "encerrado", "dias_atraso": 0, "proxima_competencia": None}
    if student["status"] == "inativo":
        return {"status": "inativo", "dias_atraso": 0, "proxima_competencia": None}

    plan = get_current_plan(student_id)
    if plan is None:
        return {"status": "sem_plano", "dias_atraso": 0, "proxima_competencia": None}

    next_due = get_next_due_competency(student_id)
    if next_due is None:
        return {"status": "em_dia", "dias_atraso": 0, "proxima_competencia": None}

    y, m = map(int, next_due.split("-"))
    due_date = date(y, m, min(plan["due_day"], 28))

    if due_date > as_of:
        return {"status": "em_dia", "dias_atraso": 0, "proxima_competencia": next_due}

    dias_atraso = (as_of - due_date).days
    tolerancia = settings_service.get_int("tolerancia_dias")
    atraso = settings_service.get_int("atraso_dias")
    inadimplencia = settings_service.get_int("inadimplencia_dias")

    if dias_atraso <= tolerancia:
        status = "em_dia"
    elif dias_atraso <= tolerancia + atraso:
        status = "atraso"
    elif dias_atraso <= tolerancia + atraso + inadimplencia:
        status = "inadimplente"
    else:
        status = "inativo_por_inadimplencia"

    return {"status": status, "dias_atraso": dias_atraso, "proxima_competencia": next_due}


def apply_automatic_inactivations(user_id: int | None = None) -> list[int]:
    """Aplica a inatividade automática (seção 30) para alunos que
    ultrapassaram o limite configurado. Retorna a lista de IDs afetados.
    Preserva todo o histórico — apenas muda o status."""
    conn = get_connection()
    ativos = conn.execute("SELECT id FROM students WHERE status='ativo';").fetchall()
    conn.close()

    affected = []
    now = _now_iso()
    for row in ativos:
        result = compute_financial_status(row["id"])
        if result["status"] == "inativo_por_inadimplencia":
            with transaction() as conn:
                conn.execute(
                    "UPDATE students SET status='inativo', updated_at=? WHERE id=?;",
                    (now, row["id"]),
                )
                conn.execute(
                    """INSERT INTO student_events (student_id, event_type, event_date, details, created_by, created_at)
                       VALUES (?, 'inatividade', ?, '{"motivo": "inadimplencia_prolongada"}', ?, ?)""",
                    (row["id"], now[:10], user_id, now),
                )
                conn.execute(
                    """INSERT INTO audit_log (user_id, action, entity, entity_id, reason, created_at)
                       VALUES (?, 'inativacao_automatica', 'students', ?, 'inadimplencia_prolongada', ?)""",
                    (user_id, row["id"], now),
                )
            affected.append(row["id"])
    if affected:
        log_info(f"Inativação automática aplicada a {len(affected)} aluno(s): {affected}")
    return affected
