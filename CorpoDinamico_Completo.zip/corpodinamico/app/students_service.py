"""
students_service.py
--------------------
Regras de negócio de alunos (seções 17-21, 41-42, 44-45).

Pontos centrais:
  - ID interno permanente (nunca depende do nome).
  - Detecção de possível duplicidade antes de criar (nome + telefone).
  - Nunca cria um aluno novo para quem está voltando: localiza e reativa.
  - Exclusão lógica apenas (status), nunca DELETE físico.
  - Toda mudança relevante vira um evento na linha do tempo do aluno.
"""

import re
import json
from datetime import datetime, timezone

from app.db import transaction, get_connection
from app.logger import log_info


def _now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S")


def _today() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def _normalize_phone(phone: str | None) -> str:
    return re.sub(r"\D", "", phone or "")


def _normalize_name(name: str) -> str:
    return " ".join(name.strip().lower().split())


def _add_event(conn, student_id: int, event_type: str, event_date: str,
               details: dict, user_id: int | None) -> None:
    conn.execute(
        """INSERT INTO student_events (student_id, event_type, event_date, details, created_by, created_at)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (student_id, event_type, event_date, json.dumps(details, ensure_ascii=False), user_id, _now_iso()),
    )


# ---------------------------------------------------------------------
# Detecção de duplicidade (seção 18)
# ---------------------------------------------------------------------
def find_possible_duplicates(full_name: str, phone: str | None = None) -> list[dict]:
    conn = get_connection()
    norm_name = _normalize_name(full_name)
    norm_phone = _normalize_phone(phone)

    candidates = conn.execute(
        "SELECT id, full_name, phone, status FROM students;"
    ).fetchall()
    conn.close()

    matches = []
    for c in candidates:
        name_match = _normalize_name(c["full_name"]) == norm_name
        phone_match = bool(norm_phone) and _normalize_phone(c["phone"]) == norm_phone
        # nome muito parecido (mesmas palavras em ordem diferente) também conta como possível duplicidade
        loose_name_match = (
            not name_match
            and set(_normalize_name(c["full_name"]).split()) == set(norm_name.split())
            and len(norm_name.split()) > 1
        )
        if name_match or phone_match or loose_name_match:
            matches.append({
                "id": c["id"], "full_name": c["full_name"], "phone": c["phone"],
                "status": c["status"],
                "motivo": "nome e telefone iguais" if (name_match and phone_match)
                          else "telefone igual" if phone_match
                          else "nome igual" if name_match else "nome muito parecido",
            })
    return matches


# ---------------------------------------------------------------------
# Cadastro (seções 42-43)
# ---------------------------------------------------------------------
def create_student(full_name: str, phone: str, address: str, birth_date: str | None,
                    notes: str, plan_id: int, value_cents: int, due_day: int,
                    start_date: str, evaluation_date: str | None, user_id: int,
                    force_despite_duplicate: bool = False) -> int:
    if not full_name or not full_name.strip():
        raise ValueError("Nome é obrigatório.")
    if value_cents < 0:
        raise ValueError("Valor não pode ser negativo.")

    if not force_despite_duplicate:
        dups = find_possible_duplicates(full_name, phone)
        if dups:
            # Não bloqueia sozinho: devolve para a tela decidir com o administrador (seção 18)
            raise DuplicateWarning(dups)

    now = _now_iso()
    with transaction() as conn:
        cur = conn.execute(
            """INSERT INTO students (full_name, phone, address, birth_date, notes,
               status, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, 'ativo', ?, ?)""",
            (full_name.strip(), phone, address, birth_date, notes, now, now),
        )
        student_id = cur.lastrowid

        conn.execute(
            """INSERT INTO student_plans (student_id, plan_id, value_cents, due_day,
               start_date, created_at, created_by)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (student_id, plan_id, value_cents, due_day, start_date, now, user_id),
        )

        _add_event(conn, student_id, "cadastro", start_date,
                   {"plan_id": plan_id, "value_cents": value_cents, "due_day": due_day}, user_id)
        if evaluation_date:
            _add_event(conn, student_id, "avaliacao", evaluation_date, {}, user_id)

        conn.execute(
            """INSERT INTO audit_log (user_id, action, entity, entity_id, new_value, created_at)
               VALUES (?, 'cadastrar_aluno', 'students', ?, ?, ?)""",
            (user_id, student_id, full_name, now),
        )
    log_info(f"Aluno cadastrado: id={student_id} nome={full_name!r}")
    return student_id


class DuplicateWarning(Exception):
    """Levantado quando há possível duplicidade. A tela deve mostrar as
    opções encontradas e perguntar ao administrador: reativar existente,
    ou confirmar que é realmente uma pessoa nova (force_despite_duplicate=True)."""
    def __init__(self, matches: list[dict]):
        self.matches = matches
        super().__init__(f"{len(matches)} possível(is) duplicidade(s) encontrada(s).")


# ---------------------------------------------------------------------
# Reativação (seções 19, 44) — NUNCA cria aluno novo para quem retorna
# ---------------------------------------------------------------------
def reactivate_student(student_id: int, plan_id: int, value_cents: int, due_day: int,
                        start_date: str, evaluation_date: str | None,
                        fee_cents: int, user_id: int) -> None:
    now = _now_iso()
    with transaction() as conn:
        student = conn.execute("SELECT * FROM students WHERE id=?;", (student_id,)).fetchone()
        if student is None:
            raise ValueError("Aluno não encontrado.")

        # encerra o vínculo de plano anterior, se ainda estiver "aberto"
        conn.execute(
            "UPDATE student_plans SET end_date=? WHERE student_id=? AND end_date IS NULL;",
            (start_date, student_id),
        )
        conn.execute(
            """INSERT INTO student_plans (student_id, plan_id, value_cents, due_day,
               start_date, created_at, created_by)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (student_id, plan_id, value_cents, due_day, start_date, now, user_id),
        )
        conn.execute(
            "UPDATE students SET status='ativo', updated_at=? WHERE id=?;",
            (now, student_id),
        )
        _add_event(conn, student_id, "reativacao", start_date, {
            "plan_id": plan_id, "value_cents": value_cents, "due_day": due_day,
            "taxa_cents": fee_cents,
        }, user_id)
        if evaluation_date:
            _add_event(conn, student_id, "avaliacao", evaluation_date, {}, user_id)

        conn.execute(
            """INSERT INTO audit_log (user_id, action, entity, entity_id, created_at)
               VALUES (?, 'reativar_aluno', 'students', ?, ?)""",
            (user_id, student_id, now),
        )
    log_info(f"Aluno reativado: id={student_id}")


# ---------------------------------------------------------------------
# Encerramento (exclusão lógica — seção 21)
# ---------------------------------------------------------------------
def close_student(student_id: int, reason: str, user_id: int) -> None:
    now = _now_iso()
    with transaction() as conn:
        conn.execute(
            "UPDATE students SET status='encerrado', updated_at=? WHERE id=?;",
            (now, student_id),
        )
        _add_event(conn, student_id, "encerramento", _today(), {"motivo": reason}, user_id)
        conn.execute(
            """INSERT INTO audit_log (user_id, action, entity, entity_id, reason, created_at)
               VALUES (?, 'encerrar_aluno', 'students', ?, ?, ?)""",
            (user_id, student_id, reason, now),
        )
    log_info(f"Aluno encerrado: id={student_id}")


def update_student(student_id: int, full_name: str, phone: str, address: str,
                    birth_date: str | None, notes: str, user_id: int) -> None:
    now = _now_iso()
    with transaction() as conn:
        old = conn.execute("SELECT * FROM students WHERE id=?;", (student_id,)).fetchone()
        conn.execute(
            """UPDATE students SET full_name=?, phone=?, address=?, birth_date=?, notes=?, updated_at=?
               WHERE id=?;""",
            (full_name, phone, address, birth_date, notes, now, student_id),
        )
        conn.execute(
            """INSERT INTO audit_log (user_id, action, entity, entity_id, old_value, new_value, created_at)
               VALUES (?, 'editar_aluno', 'students', ?, ?, ?, ?)""",
            (user_id, student_id, old["full_name"], full_name, now),
        )


# ---------------------------------------------------------------------
# Consultas
# ---------------------------------------------------------------------
def list_students(status: str | None = None, search: str | None = None) -> list[dict]:
    conn = get_connection()
    query = "SELECT * FROM students WHERE 1=1"
    params = []
    if status:
        query += " AND status=?"
        params.append(status)
    if search:
        query += " AND (full_name LIKE ? OR phone LIKE ?)"
        like = f"%{search}%"
        params += [like, like]
    query += " ORDER BY full_name ASC;"
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_student(student_id: int) -> dict | None:
    conn = get_connection()
    row = conn.execute("SELECT * FROM students WHERE id=?;", (student_id,)).fetchone()
    if row is None:
        conn.close()
        return None
    student = dict(row)

    plan_row = conn.execute(
        """SELECT sp.*, p.name as plan_name FROM student_plans sp
           JOIN plans p ON p.id = sp.plan_id
           WHERE sp.student_id=? AND sp.end_date IS NULL
           ORDER BY sp.start_date DESC LIMIT 1;""",
        (student_id,),
    ).fetchone()
    student["current_plan"] = dict(plan_row) if plan_row else None

    events = conn.execute(
        "SELECT * FROM student_events WHERE student_id=? ORDER BY event_date DESC, id DESC;",
        (student_id,),
    ).fetchall()
    student["timeline"] = [dict(e) for e in events]

    conn.close()
    return student
