"""
db.py
-----
Conexão com o banco SQLite e utilitário de transação segura.

Decisões técnicas (documentadas conforme seção 15/16 do escopo):
  * SQLite foi escolhido porque: é embutido no Python (zero dependência
    extra), é um arquivo único (portátil, fácil de fazer backup/copiar),
    suporta transações ACID reais, foreign keys e índices, e é a opção
    padrão da indústria para aplicações desktop single-file como esta.
  * journal_mode=WAL: torna a escrita mais resistente a quedas de energia
    e permite leitura concorrente sem travar o banco inteiro (seção 52).
  * foreign_keys=ON: integridade referencial real, não apenas "de boa fé".
  * Toda escrita passa pelo context manager `transaction()`, que faz
    commit no sucesso e rollback automático em qualquer exceção — nenhuma
    escrita parcial fica gravada (seção 52).
"""

import sqlite3
import contextlib
from app.paths import DATABASE_PATH, ensure_all_dirs
from app.logger import log_error, log_info


def get_connection() -> sqlite3.Connection:
    ensure_all_dirs()
    conn = sqlite3.connect(DATABASE_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = FULL;")  # prioriza integridade sobre velocidade
    return conn


@contextlib.contextmanager
def transaction():
    """
    Uso:
        with transaction() as conn:
            conn.execute("INSERT ...", (...))
    Se qualquer exceção ocorrer dentro do bloco, TUDO é revertido
    (nenhuma escrita parcial). Se tudo correr bem, faz commit único.
    """
    conn = get_connection()
    try:
        conn.execute("BEGIN IMMEDIATE;")
        yield conn
        conn.commit()
    except Exception as exc:
        conn.rollback()
        log_error("Transação revertida (rollback) por erro", exc)
        raise
    finally:
        conn.close()


def check_integrity() -> tuple[bool, str]:
    """Roda o verificador de integridade nativo do SQLite.
    Usado pela tela 'Saúde do sistema' (seção 49)."""
    try:
        conn = get_connection()
        row = conn.execute("PRAGMA integrity_check;").fetchone()
        conn.close()
        ok = row[0] == "ok"
        return ok, row[0]
    except Exception as exc:
        log_error("Falha ao checar integridade do banco", exc)
        return False, str(exc)
