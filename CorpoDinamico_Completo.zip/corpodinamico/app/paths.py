r"""
paths.py
--------
Resolucao de caminhos do Corpo Dinamico - versao "arquivo unico".

Filosofia (mudou por pedido explicito do usuario): o programa e UM UNICO
arquivo .exe. Ele pode ficar sozinho em qualquer pasta - Desktop, Downloads,
pendrive - sem nenhuma pasta irma que precise viajar junto. Por isso:

  - Os ARQUIVOS INTERNOS do programa (templates, css, logo, sql das
    migrations) ficam EMBUTIDOS dentro do proprio .exe (gerados pelo
    PyInstaller em modo onefile) e sao acessados via resource_path().
    Sao somente leitura e nunca precisam ficar "ao lado" do .exe.

  - Os DADOS DA ACADEMIA (banco, backups, logs, relatorios) NUNCA ficam
    ao lado do .exe (isso e exatamente o que causava o risco de "perder
    a pasta" se alguem movesse so o .exe). Em vez disso, ficam sempre
    numa pasta fixa e propria do usuario do Windows:

        %LOCALAPPDATA%\CorpoDinamico

    Essa pasta existe independente de onde o .exe esta guardado no
    momento, sobrevive a mover/copiar/renomear o .exe, e nunca e uma
    letra de unidade fixa (e resolvida pelo proprio Windows, por usuario).

  - Em modo desenvolvimento (rodando via `python main.py`, sem estar
    "congelado" pelo PyInstaller), usa-se uma pasta local de conveniencia
    dentro do proprio projeto, so para facilitar testes.
"""

import sys
import os


def is_frozen() -> bool:
    return getattr(sys, "frozen", False)


def resource_path(*parts: str) -> str:
    """
    Caminho para um arquivo INTERNO/somente-leitura do programa (templates,
    css, imagens da logo, sql de migrations). Funciona tanto rodando como
    .exe empacotado (onefile do PyInstaller, que extrai tudo para uma pasta
    temporaria indicada por sys._MEIPASS) quanto rodando como script Python
    puro durante o desenvolvimento.
    """
    if is_frozen():
        base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(sys.executable)))
    else:
        base = os.path.dirname(os.path.abspath(__file__))  # .../app
        base = os.path.dirname(base)  # raiz do projeto
    return os.path.join(base, *parts)


def get_exe_dir() -> str:
    """Pasta onde o .exe (arquivo unico) realmente esta guardado no
    computador do usuario. Usado so para diagnostico (tela de Saude do
    sistema) - os dados NAO ficam aqui."""
    if is_frozen():
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def get_data_root() -> str:
    """
    Pasta fixa e sempre gravavel para os dados da academia. Nunca depende
    de onde o .exe esta - por isso nunca se "perde" mesmo movendo o .exe
    sozinho para outro lugar.
    """
    if is_frozen():
        local_appdata = os.environ.get("LOCALAPPDATA")
        if local_appdata:
            return os.path.join(local_appdata, "CorpoDinamico")
        # fallback raro (LOCALAPPDATA ausente): pasta do usuario
        return os.path.join(os.path.expanduser("~"), "CorpoDinamico")
    # Modo desenvolvimento: pasta de conveniencia dentro do proprio projeto
    dev_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(dev_root, "_dados_dev")


BASE_DIR = get_exe_dir()
DATA_ROOT = get_data_root()

DATA_DIR = os.path.join(DATA_ROOT, "data")
DATABASE_DIR = os.path.join(DATA_DIR, "database")
DATABASE_PATH = os.path.join(DATABASE_DIR, "corpodinamico.db")

BACKUPS_DIR = os.path.join(DATA_ROOT, "backups")
LOGS_DIR = os.path.join(DATA_ROOT, "logs")
CONFIG_DIR = os.path.join(DATA_ROOT, "config")
REPORTS_DIR = os.path.join(DATA_ROOT, "reports")

# A logo/assets ficam EMBUTIDAS dentro do .exe (somente leitura) - nao sao
# "dados", entao usam resource_path, nao o DATA_ROOT.
ASSETS_DIR = resource_path("assets")
LOGO_DIR = os.path.join(ASSETS_DIR, "logo")

CONFIG_PATH = os.path.join(CONFIG_DIR, "config.json")
LOG_PATH = os.path.join(LOGS_DIR, "sistema.log")


def ensure_all_dirs() -> None:
    """Garante que toda a estrutura de pastas DE DADOS existe (a pasta
    fixa em %LOCALAPPDATA%, nunca ao lado do .exe)."""
    for d in (DATA_DIR, DATABASE_DIR, BACKUPS_DIR, LOGS_DIR, CONFIG_DIR, REPORTS_DIR):
        os.makedirs(d, exist_ok=True)
